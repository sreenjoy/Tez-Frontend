# Tez Frontend

Frontend application for Tez platform.

## Documentation

Documentation templates are stored in the `/documentation` directory to benchmark and track performance optimization efforts.

## Development

```bash
npm run dev
```

## Build

```bash
npm run build
``` 