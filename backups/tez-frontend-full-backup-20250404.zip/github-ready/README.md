# Tez Frontend

A modern, responsive frontend for the Tez CRM platform with pipeline management, deal tracking, and chat integrations.

## Features

- Pipeline view for managing deals across different stages
- Detailed deal pages with chat and scheduling functionality
- Light/dark mode support
- Responsive design for all devices
- Real-time chat synchronization

## Quick Start

### Option 1: Using the bundled package

1. Clone this repository
2. Install the bundled package:
```bash
npm install ./tez-frontend-0.1.0.tgz
```

3. Run the development server:
```bash
npm run dev
```

### Option 2: Standard installation

1. Clone this repository
2. Install dependencies:
```bash
npm install
```

3. Run the development server:
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Production Build

```bash
npm run build
npm start
```

## Project Structure

- `/src/app` - Next.js app router pages and layouts
- `/src/components` - Reusable UI components
- `/src/styles` - Global CSS and Tailwind configuration

## System Requirements

- Node.js 18.0 or later
- npm 9.0 or later

## Tech Stack

- Next.js 15
- React 18
- Tailwind CSS
- TypeScript

## Documentation

Documentation templates are stored in the `/documentation` directory to benchmark and track performance optimization efforts.

## Development

```bash
npm run dev
```

## Build

```bash
npm run build
``` 