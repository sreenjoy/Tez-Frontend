This directory is ready to be pushed to GitHub. It contains a bundled version of the Tez Frontend application.
